package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.entity.Topic;

public interface TopicRespository extends CrudRepository<Topic, String>{

}
